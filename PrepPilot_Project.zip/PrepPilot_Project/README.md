# PrepPilot — Resume & Career Preparation App

A responsive front-end prototype built with HTML, CSS, and JavaScript.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. No build tools or installation are required.

## Features in this prototype
- Landing page and navigation
- Sign-up / login interface (demo only)
- Resume analyzer with rule-based demo scoring
- Resume draft builder
- Sample aptitude mock test and score
- Preparation-plan form
- Coach request interface
- Subscription-plan preview
- Preparation dashboard, task checklist, and progress bars
- Responsive layout for desktop and mobile

## Important limitations
This is a front-end prototype. Authentication, cloud persistence, a real AI resume API, email/coach booking, payment processing, and verified placement integrations are not connected. Demo data is not stored on a server and may reset when the page is refreshed. Do not use real passwords or sensitive personal data in the demo.

## Share with teammates
- Send them `PrepPilot_Project.zip`, or
- Put `index.html` in a GitHub repository and enable GitHub Pages to share a browser link.
